
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.changedmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;

import net.mcreator.changedmod.block.VentOpenBlock;
import net.mcreator.changedmod.block.VentBlock;
import net.mcreator.changedmod.block.SaveStationBlock;
import net.mcreator.changedmod.block.DrainBlock;
import net.mcreator.changedmod.block.CautionFloorBlock;
import net.mcreator.changedmod.ChangedMod;

public class ChangedModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, ChangedMod.MODID);
	public static final RegistryObject<Block> SAVE_STATION = REGISTRY.register("save_station", () -> new SaveStationBlock());
	public static final RegistryObject<Block> DRAIN = REGISTRY.register("drain", () -> new DrainBlock());
	public static final RegistryObject<Block> VENT = REGISTRY.register("vent", () -> new VentBlock());
	public static final RegistryObject<Block> CAUTION_FLOOR = REGISTRY.register("caution_floor", () -> new CautionFloorBlock());
	public static final RegistryObject<Block> VENT_OPEN = REGISTRY.register("vent_open", () -> new VentOpenBlock());

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			SaveStationBlock.registerRenderLayer();
			DrainBlock.registerRenderLayer();
			VentBlock.registerRenderLayer();
			CautionFloorBlock.registerRenderLayer();
			VentOpenBlock.registerRenderLayer();
		}
	}
}
