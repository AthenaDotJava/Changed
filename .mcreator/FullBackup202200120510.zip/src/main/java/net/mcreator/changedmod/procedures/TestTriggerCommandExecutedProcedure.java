package net.mcreator.changedmod.procedures;

import net.mcreator.changedmod.ChangedMod;

public class TestTriggerCommandExecutedProcedure {
	public static void execute() {
		ChangedMod.LOGGER.info("Trigger Triggered");
	}
}
