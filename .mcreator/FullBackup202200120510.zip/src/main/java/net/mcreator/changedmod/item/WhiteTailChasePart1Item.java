
package net.mcreator.changedmod.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.RecordItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.network.chat.Component;

import net.mcreator.changedmod.init.ChangedModTabs;
import net.mcreator.changedmod.init.ChangedModSounds;

import java.util.List;

public class WhiteTailChasePart1Item extends RecordItem {
	public WhiteTailChasePart1Item() {
		super(0, ChangedModSounds.REGISTRY.get(new ResourceLocation("changed:whitetailchasept1")),
				new Item.Properties().tab(ChangedModTabs.TAB_CHANGED).stacksTo(1).rarity(Rarity.RARE));
	}

	@Override
	public void appendHoverText(ItemStack itemstack, Level world, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(itemstack, world, list, flag);
		list.add(new TextComponent("Track 07"));
	}
}
