
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.changedmod.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import java.util.Map;
import java.util.HashMap;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ChangedModSounds {
	public static Map<ResourceLocation, SoundEvent> REGISTRY = new HashMap<>();
	static {
		REGISTRY.put(new ResourceLocation("changed", "thewhiteknight"), new SoundEvent(new ResourceLocation("changed", "thewhiteknight")));
		REGISTRY.put(new ResourceLocation("changed", "catchase"), new SoundEvent(new ResourceLocation("changed", "catchase")));
		REGISTRY.put(new ResourceLocation("changed", "blackgoozone"), new SoundEvent(new ResourceLocation("changed", "blackgoozone")));
		REGISTRY.put(new ResourceLocation("changed", "crystalzone"), new SoundEvent(new ResourceLocation("changed", "crystalzone")));
		REGISTRY.put(new ResourceLocation("changed", "crystaldragon"), new SoundEvent(new ResourceLocation("changed", "crystaldragon")));
		REGISTRY.put(new ResourceLocation("changed", "whitetailchasept1"), new SoundEvent(new ResourceLocation("changed", "whitetailchasept1")));
		REGISTRY.put(new ResourceLocation("changed", "thelibrary"), new SoundEvent(new ResourceLocation("changed", "thelibrary")));
		REGISTRY.put(new ResourceLocation("changed", "whitetailchasept2"), new SoundEvent(new ResourceLocation("changed", "whitetailchasept2")));
		REGISTRY.put(new ResourceLocation("changed", "puroandtheblackgoo"), new SoundEvent(new ResourceLocation("changed", "puroandtheblackgoo")));
		REGISTRY.put(new ResourceLocation("changed", "ventpipe"), new SoundEvent(new ResourceLocation("changed", "ventpipe")));
		REGISTRY.put(new ResourceLocation("changed", "theshark"), new SoundEvent(new ResourceLocation("changed", "theshark")));
		REGISTRY.put(new ResourceLocation("changed", "puroshome"), new SoundEvent(new ResourceLocation("changed", "puroshome")));
		REGISTRY.put(new ResourceLocation("changed", "ventpipecheetarchase"),
				new SoundEvent(new ResourceLocation("changed", "ventpipecheetarchase")));
		REGISTRY.put(new ResourceLocation("changed", "thesquiddog"), new SoundEvent(new ResourceLocation("changed", "thesquiddog")));
		REGISTRY.put(new ResourceLocation("changed", "whitegoojungle"), new SoundEvent(new ResourceLocation("changed", "whitegoojungle")));
		REGISTRY.put(new ResourceLocation("changed", "lionchase"), new SoundEvent(new ResourceLocation("changed", "lionchase")));
		REGISTRY.put(new ResourceLocation("changed", "laboratory"), new SoundEvent(new ResourceLocation("changed", "laboratory")));
		REGISTRY.put(new ResourceLocation("changed", "scarletcrystalmine"), new SoundEvent(new ResourceLocation("changed", "scarletcrystalmine")));
		REGISTRY.put(new ResourceLocation("changed", "thebadend"), new SoundEvent(new ResourceLocation("changed", "thebadend")));
		REGISTRY.put(new ResourceLocation("changed", "outsideofthetower"), new SoundEvent(new ResourceLocation("changed", "outsideofthetower")));
		REGISTRY.put(new ResourceLocation("changed", "finale"), new SoundEvent(new ResourceLocation("changed", "finale")));
		REGISTRY.put(new ResourceLocation("changed", "crueltruth"), new SoundEvent(new ResourceLocation("changed", "crueltruth")));
		REGISTRY.put(new ResourceLocation("changed", "birthdaysong"), new SoundEvent(new ResourceLocation("changed", "birthdaysong")));
		REGISTRY.put(new ResourceLocation("changed", "purodance"), new SoundEvent(new ResourceLocation("changed", "purodance")));
		REGISTRY.put(new ResourceLocation("changed", "gasroom"), new SoundEvent(new ResourceLocation("changed", "gasroom")));
	}

	@SubscribeEvent
	public static void registerSounds(RegistryEvent.Register<SoundEvent> event) {
		for (Map.Entry<ResourceLocation, SoundEvent> sound : REGISTRY.entrySet())
			event.getRegistry().register(sound.getValue().setRegistryName(sound.getKey()));
	}
}
