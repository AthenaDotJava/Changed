package net.mcreator.changedmod.procedures;

public class SaveProcedure {
	public static void execute() {
	}
}
